# Weekly Review

## Performance Snapshot (Past 7 Days)
# Weekly Performance Metrics

## Winners (Outbound Clicks / Impressions)
1. PIN-001 | /hub/styling-mirrors-lighting-color | 0.00%
2. PIN-002 | /hub/bathroom-plants-biophilic-vibe | 0.00%
3. PIN-003 | /lead-magnets/plant-picker | 0.00%
4. PIN-004 | /products/renter-bathroom-upgrade-blueprint | 0.00%
5. PIN-005 | /products/bathroom-plant-picks-upgrade | 0.00%
6. PIN-006 | /hub/styling-mirrors-lighting-color | 0.00%
7. PIN-007 | /hub/bathroom-plants-biophilic-vibe | 0.00%
8. PIN-008 | /lead-magnets/plant-picker | 0.00%
9. PIN-009 | /products/renter-bathroom-upgrade-blueprint | 0.00%
10. PIN-010 | /products/bathroom-plant-picks-upgrade | 0.00%

## Top Hook Classes
- BeforeAfter: 0.00%
- Checklist: 0.00%
- MistakesToAvoid: 0.00%
- QuickWin: 0.00%
- BudgetBreakdown: 0.00%
- StepByStepHowTo: 0.00%
- ProductRoundup: 0.00%
- PlantPicker: 0.00%
- RenterHack: 0.00%
- SmallSpaceTrick: 0.00%

## Top Destination Intents
- Inspire: 0.00%
- Teach: 0.00%
- Solve: 0.00%
- Shop: 0.00%
- Subscribe: 0.00%

## Destination Type Performance
- hub: 0.00%
- lead: 0.00%
- product: 0.00%

## Recommendation
- Shift 20% of next batch toward top 2 hook classes and top 2 intents.
- Keep URL cooldown and published-only checks strict.


## Quality and Compliance Audit
- Banned phrase check active.
- Sales-tone naturalness check active.
- Visual risk flags active for policy-sensitive prompt terms.
- URL cooldown and published-only destination checks active.

## What to Improve Next Week
1. Push 20% more volume toward top-performing hook classes in outbound clicks per impression.
2. Keep intent mix balanced; avoid same-intent clustering on the same day.
3. Refresh 5 winners with new overlays, not just new captions.
4. Prioritize conversion-ready destinations: Start Here, Plant Picker, and approved product pages.

## Ops Inputs
The schedule plan below is consumed by weekly_ops_info:

# Weekly Schedule Plan

## Constraints Check
- Published-only destinations: enforced via URL inventory filter.
- URL cooldown 24h: enforced via scheduler.
- Human approval required for blog publish and pin export.

## Schedule
- 2026-03-02T00:00:00.000Z | PIN-001 | Inspire | BeforeAfter | /hub/styling-mirrors-lighting-color
- 2026-03-02T03:00:00.000Z | PIN-002 | Teach | Checklist | /hub/bathroom-plants-biophilic-vibe
- 2026-03-02T06:00:00.000Z | PIN-003 | Solve | MistakesToAvoid | /lead-magnets/plant-picker
- 2026-03-02T09:00:00.000Z | PIN-004 | Shop | QuickWin | /products/renter-bathroom-upgrade-blueprint
- 2026-03-02T23:00:00.000Z | PIN-005 | Subscribe | BudgetBreakdown | /products/bathroom-plant-picks-upgrade
- 2026-03-03T02:00:00.000Z | PIN-006 | Inspire | StepByStepHowTo | /hub/styling-mirrors-lighting-color
- 2026-03-03T05:00:00.000Z | PIN-007 | Teach | ProductRoundup | /hub/bathroom-plants-biophilic-vibe
- 2026-03-03T08:00:00.000Z | PIN-008 | Solve | PlantPicker | /lead-magnets/plant-picker
- 2026-03-03T22:00:00.000Z | PIN-009 | Shop | RenterHack | /products/renter-bathroom-upgrade-blueprint
- 2026-03-04T01:00:00.000Z | PIN-010 | Subscribe | SmallSpaceTrick | /products/bathroom-plant-picks-upgrade
- 2026-03-04T04:00:00.000Z | PIN-011 | Inspire | StylingFormula | /hub/styling-mirrors-lighting-color
- 2026-03-04T07:00:00.000Z | PIN-012 | Teach | MythBuster | /hub/bathroom-plants-biophilic-vibe
- 2026-03-04T21:00:00.000Z | PIN-013 | Solve | BeforeAfter | /lead-magnets/plant-picker
- 2026-03-05T00:00:00.000Z | PIN-014 | Shop | Checklist | /products/renter-bathroom-upgrade-blueprint
- 2026-03-05T03:00:00.000Z | PIN-015 | Subscribe | MistakesToAvoid | /products/bathroom-plant-picks-upgrade
- 2026-03-05T06:00:00.000Z | PIN-016 | Inspire | QuickWin | /hub/styling-mirrors-lighting-color
- 2026-03-05T20:00:00.000Z | PIN-017 | Teach | BudgetBreakdown | /hub/bathroom-plants-biophilic-vibe
- 2026-03-05T23:00:00.000Z | PIN-018 | Solve | StepByStepHowTo | /lead-magnets/plant-picker
- 2026-03-06T02:00:00.000Z | PIN-019 | Shop | ProductRoundup | /products/renter-bathroom-upgrade-blueprint
- 2026-03-06T05:00:00.000Z | PIN-020 | Subscribe | PlantPicker | /products/bathroom-plant-picks-upgrade
- 2026-03-06T19:00:00.000Z | PIN-021 | Inspire | RenterHack | /hub/styling-mirrors-lighting-color
- 2026-03-06T22:00:00.000Z | PIN-022 | Teach | SmallSpaceTrick | /hub/bathroom-plants-biophilic-vibe
- 2026-03-07T01:00:00.000Z | PIN-023 | Solve | StylingFormula | /lead-magnets/plant-picker
- 2026-03-07T04:00:00.000Z | PIN-024 | Shop | MythBuster | /products/renter-bathroom-upgrade-blueprint
- 2026-03-07T18:00:00.000Z | PIN-025 | Subscribe | BeforeAfter | /products/bathroom-plant-picks-upgrade

## Warnings
- none

## Validation Issues
- none

## Experiments
- Experiment A: Compare QuickWin vs StepByStepHowTo for outbound click rate. Success threshold: +15% outbound CTR.
- Experiment B: Product page CTA block variants on Solve intent pins. Success threshold: +10% email signup clicks.

## Winner Refresh Tasks
- Refresh task 1: top outbound-click winner -> new overlay variant.
- Refresh task 2: top save-rate winner -> stronger CTA block.
- Refresh task 3: top Teach-intent winner -> alternate image prompt composition.
- Refresh task 4: top Shop-intent winner -> price-framing rewrite.
- Refresh task 5: top Subscribe-intent winner -> lead magnet angle rewrite.

## Priorities
- Prioritize outbound click optimization on Teach/Solve destinations.
- Refresh top 5 winners with new overlays and prompt angle.
- Protect intent mix daily; avoid Shop clustering.
- Only export/publish human-approved rows.

